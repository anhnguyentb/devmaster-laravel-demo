@extends('layouts/default')

@section('content')
    <div class="container text-center">
        <h3>Welcome <b>{{$username}}</b> to our application</h3>
    </div>
@endsection
