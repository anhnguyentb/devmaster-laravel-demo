<?php
session_start();

echo $_SESSION['test_session'];
