<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <h3>Welcome <b><?php echo e($username); ?></b> to our application</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/home.blade.php ENDPATH**/ ?>