<?php $__env->startSection('footer'); ?>
    <h4>This is footer from child-detail</h4>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/child-detail.blade.php ENDPATH**/ ?>