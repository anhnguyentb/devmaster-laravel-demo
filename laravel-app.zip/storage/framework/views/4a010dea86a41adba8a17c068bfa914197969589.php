<h1>This is header</h1>
<?php /**PATH /var/www/resources/views/header.blade.php ENDPATH**/ ?>