

<ul>
    <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($car); ?></li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</ul>

<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php if($color == "blue"): ?>
    <h1 style="color: blue">Hello, <?php echo e($name); ?></h1>
<?php else: ?>
    <h1 style="color: red">Hello, <?php echo e($name); ?></h1>
<?php endif; ?>

<?php if (! ($foo)): ?>
    <h3>Foo variable is not found</h3>
<?php endif; ?>

<?php for($i = 0; $i < 10; $i++): ?>
    <h4>The current item is <?php echo e($i); ?></h4>
<?php endfor; ?>
<?php /**PATH /var/www/resources/views/hello.blade.php ENDPATH**/ ?>