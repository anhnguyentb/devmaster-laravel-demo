<?php $__env->startSection('header-text'); ?>
    List classes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row mb-3">
            <a href="/class/add" class="btn btn-primary">Add Class</a>
        </div>
        <div class="row">
            <table class="table">
                <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Year</th>
                    <th>Holder Name</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($class->id); ?></td>
                        <td><?php echo e($class->name); ?></td>
                        <td><?php echo e($class->year); ?></td>
                        <td><?php echo e($class->holder_name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div class="row justify-content-center">
            <nav>
                <ul class="pagination">
                    <?php for($i = 1; $i <= $numberOfPage; $i++): ?>
                        <li class="page-item <?php echo e(($page == $i) ? 'active' : ''); ?>">
                            <a class="page-link" href="/class/<?php echo e($i); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>
                </ul>
            </nav>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/classes/list.blade.php ENDPATH**/ ?>