<p>Pagination</p>
<?php for($i = 1; $i <= $numberOfPages; $i++): ?>
    <a href="/list-films-2/<?php echo e($i); ?>/<?php echo e($limit); ?>" style="padding-right: 10px"><?php echo e($i); ?></a>
<?php endfor; ?>
<br/>
<select id="limitOption">
    <?php $__currentLoopData = $limitOpts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $limitOpt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($limitOpt); ?>" <?php echo e(($limitOpt == $limit) ? 'selected="selected"' : ''); ?>><?php echo e($limitOpt); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>

<table border="1" cellspacing="1">
    <thead>
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Description</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($film->film_id); ?></td>
            <td><?php echo e($film->title); ?></td>
            <td><?php echo e($film->description); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<script type="text/javascript">
    const selectEl = document.getElementById('limitOption');
    selectEl.addEventListener('change', function() {
        const limit = selectEl.value;
        document.location.href = '/list-films-2/1/' + limit;
    });
</script>
<?php /**PATH /var/www/resources/views/films.blade.php ENDPATH**/ ?>