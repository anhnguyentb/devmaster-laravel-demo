<?php $__env->startSection('header'); ?>
    <h2>This is header from child template</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/detail.blade.php ENDPATH**/ ?>