<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\MessageBag;

class AuthenticateController extends BaseController
{
    public function login(Request $req)
    {
        $errors = new MessageBag();
        if (!empty($req->post())) {
            // User's submitting data
            $validators = Validator::make($req->post(), [
                'username' => 'required|min:5',
                'password' => 'required|min:5'
            ]);

            if (!$validators->fails()) {
                // User's data correct
                $user = $req->post('username');
                $pwd = $req->post('password');
                if ($user == 'admin' && $pwd == 'admin') {
                    $req->session()->put('isLoggedIn', true);
                    $req->session()->put('username', $user);
                    return redirect('/home');
                } else {
                    $errors->add("", "The credentials are incorrect");
                }
            } else {
                $errors = $validators->errors();
            }

        }
        return view('login', [
            'errors' => $errors
        ]);
    }
}
